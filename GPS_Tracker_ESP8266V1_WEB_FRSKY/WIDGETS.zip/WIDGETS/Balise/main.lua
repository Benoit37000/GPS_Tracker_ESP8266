local options = { }

local gps   = "GPS"
local sat   = "SAT"
local hdop  = "HDOP"


function create(zone, options)
	local widget = { zone=zone, options=options }
	return widget
end

function update(widget, options)
	widget.options = options
end

function background(widget)
end

function draw_status(x,y,src)
    local msg_table = {
		[0]  = "No Status",
		[1]  = "No RC Signal",
		[2] = "Ready"
	}
	local status = getValue(src)
	status_str = msg_table[status] 
	lcd.drawText(x+45,y,"STATUS",0)
	lcd.drawText(x+5,y+30,status_str,MIDSIZE)
end

function draw_gps(widget,src)
	lcd.drawText(widget.zone.x,widget.zone.y,"GPS:",MIDSIZE)
	local gpsData = getValue("GPS")
	if type(gpsData) == "table" and gpsData.lat ~= nil and gpsData.lon ~= nil then
		lcd.drawText(widget.zone.x+70,widget.zone.y,gpsData.lat,MIDSIZE+ TEXT_COLOR)
		lcd.drawText(widget.zone.x+70,widget.zone.y+20,gpsData.lon,MIDSIZE+ TEXT_COLOR)
	end  
end

function draw_sat(widget,src)
	local sat = getValue(src)
	lcd.drawText(widget.zone.x,widget.zone.y+40,"SAT:",0)
	lcd.drawNumber(widget.zone.x+65,widget.zone.y+40,sat,RIGHT)
end

function draw_hdop(widget,src)
	local hdop = getValue(src)*10
	lcd.drawText(widget.zone.x,widget.zone.y+55,"HDOP:",0)
	lcd.drawNumber(widget.zone.x+90,widget.zone.y+55,hdop*10,RIGHT+PREC2)
end

function refresh(widget)
	lcd.setColor(CUSTOM_COLOR,WHITE)
	lcd.setColor(LINE_COLOR,BLACK)
-- 	lcd.drawText(widget.zone.x +0, widget.zone.y + 10, "0-10", 0 + TEXT_COLOR)
--	lcd.drawText(widget.zone.x +0, widget.zone.y + 20, "0-20", 0 + TEXT_COLOR)
--	lcd.drawText(widget.zone.x +0, widget.zone.y + 80, "0-80", 0 + TEXT_COLOR) 
	
	draw_gps(widget,gps)
	draw_sat(widget,sat)
	draw_hdop(widget,hdop)
end

return { name="Balise V1", options=options, create=create, update=update, background=background, refresh=refresh }

